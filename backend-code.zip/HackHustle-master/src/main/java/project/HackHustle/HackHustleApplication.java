package project.HackHustle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackHustleApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(HackHustleApplication.class, args);
	}

}
